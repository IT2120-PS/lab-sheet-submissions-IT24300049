setwd("C:\\Users\\it24300049\\Desktop\\IT24300049")
# Use comma as separator
branch_data <- read.csv("Exercise.txt", header = TRUE)

attach(branch_data)


#Branch → Categorical, Nominal
#Sales_X1 → Numeric (continuous), Ratio
#Advertising_X2 → Numeric, Ratio
#Years_X3 → Numeric (discrete), Ratio


# Now plot
boxplot(Sales_X1, main = "Sales (X1)", ylab = "Sales")


fivenum(Advertising_X2)
IQR(Advertising_X2)

# Optional to see quartiles
quantile(Advertising_X2, probs = c(0, 0.25, 0.5, 0.75, 1))

#Part 4
#Function to check the existence of outliers of a data set
get_outliers <- function(z) {
  q1 <- quantile(z)[2]
  q3 <- quantile(z)[4]
  iqr <- q3 - q1
  ub <- q3 + 1.5*iqr
  lb <- q1 - 1.5*iqr
  
  print(paste("Upper Bound = ", ub))
  print(paste("Lower Bound = ", lb))
  print(paste("Outliers:", paste(sort(z[z < lb | z > ub]), collapse = ", ")))
}

#Checking the outliers of a variable using the function defined above
get_outliers(Sales_X1)
get_outliers(Advertising_X2)
get_outliers(Years_X3)

