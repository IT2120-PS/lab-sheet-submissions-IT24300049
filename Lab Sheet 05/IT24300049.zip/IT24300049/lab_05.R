setwd("D:\\Sliit\\2nd Year\\1st Sem\\Pro&Stat\\Lab\\Lab05")


Delivery_Times <- read.table("Exercise - Lab 05.txt", header = TRUE)

# Attach the data frame to call variables by name
attach(Delivery_Times)

#for2nd
delivery_hist <- hist(Delivery_Time_.minutes.,
                      main = "Histogram for Delivery Times",
                      xlab = "Delivery Time (minutes)",
                      breaks = seq(20, 70, length = 10),
                      right = FALSE)

#Based on the histogram, the shape of the distribution of delivery times can be described as roughly symmetric 
#and unimodal (having a single peak).
#The frequencies increase towards the center and then decrease, resembling a bell-like shape. 
#The peak occurs in the class interval of approximately 36.7 to 42.2 minutes.


# Step 4: Draw a cumulative frequency polygon (ogive) for the data
# Extract frequencies and break points from the histogram object
freq <- delivery_hist$counts
breaks <- delivery_hist$breaks

#Calculate cumulative frequencies using cumsum()
cum.freq <- cumsum(freq)

# Create a new vector for plotting the ogive, starting with a
new_cum_freq <- c()


for (i in 1:length(breaks)) {
  if(i == 1){
    new_cum_freq[i] <- 0
  } else {
    new_cum_freq[i] <- cum.freq[i-1]
  }
}

new_cum_freq
freq
breaks

# [cite_start]Draw the cumulative frequency polygon (ogive) in a new plot.
plot(breaks, new_cum_freq,
     type = "o",  # "o" for points connected by lines
     main = "Ogive for Delivery Times",
     xlab = "Delivery Time (minutes)",
     ylab = "Cumulative Frequency",
     ylim = c(0, max(cum.freq)))











